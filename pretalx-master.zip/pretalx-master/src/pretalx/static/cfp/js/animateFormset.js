jQuery(function($) {
  $(".formset").formset({
    animateForms: true,
  })
})

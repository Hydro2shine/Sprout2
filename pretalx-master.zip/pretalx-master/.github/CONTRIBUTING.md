Contributing to pretalx
=======================

Hey there and welcome to pretalx!

We've got an contributors guide in [our documentation](http://pretalx.readthedocs.io/en/latest/developer/index.html).

Please note that we have a [Code of Conduct](https://github.com/pretalx/pretalx/blob/master/CODE_OF_CONDUCT.md) in place
that applies to all project contributions, including issues, pull requests, etc.

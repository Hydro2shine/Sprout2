---
name: Feature Request
about: Suggest a new feature for this project!

---

## Problem you are facing


## Possible Solution


## Context

<!--- How has this issue affected you? What are you trying to accomplish? -->
<!--- Providing context helps us come up with the solution that is most useful in the real world -->


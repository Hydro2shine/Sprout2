Resources and endpoints
=======================

.. toctree::
   :maxdepth: 2

   events
   submissions
   talks
   speakers
   reviews
   rooms
